<?php

/**
 * class ExtendedChinAmNameType
 * module ChinAmNameTypeAddon
 * custom module to add more relation descriptors which are used in ASSO:TYPE or _ASSO:TYPE
 *
 * webtrees: online genealogy
 * Copyright (C) 2022 Hermann Hartenthaler
 * Copyright (C) 2022 webtrees development team
 *
 * This program is free software: you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
 * GNU General Public License for more details.
 * You should have received a copy of the GNU General Public License
 * along with this program. If not, see <https://www.gnu.org/licenses/>.
 */

declare(strict_types=1);

namespace Hartenthaler\Webtrees\Module\ChinAmNameTypeAddon;

use Fisharebest\Webtrees\Elements\NameType;
use Fisharebest\Webtrees\I18N;

use function uasort;

/*
 * class extends original class NameType with custom descriptor values
 */
class ExtendedChinAmNameType extends NameType
{

	public const VALUE_HOISAN      = '台山话 HOISAN VA OR TAISHANESE';
    public const VALUE_PHONETIC    = 'LOCAL PHONETIC SPELLING';
    public const VALUE_PAPER       = 'PAPER';
    public const VALUE_SIMPLIFIED  = 'SIMPLIFIED';
    public const VALUE_TRADITIONAL = 'TRADITIONAL';
    public const VALUE_YALE        = '耶鲁/耶魯 YALE';
    public const VALUE_JYUTPING    = '粤拼/粵拼 JYUTPING';
    public const VALUE_PINYIN      = '拼音 PINYIN';
    public const VALUE_ZI          = '字 ZI';
    public const VALUE_HAO         = '號 HAO';
    public const VALUE_HUI         = '諱 HUI OR ADULT';
    public const VALUE_MILK        = '小名/乳名 MILK OR RUMING OR XIAOMING';
	public const VALUE_BABY        = '諱 SHUN OR CONCEAL BABY NAME';
    protected const SEX = ['M', 'F', 'U'];

    /**
     * provides additional custom relation descriptors
     * Replace the example lines in this function by your custom descriptors!
     *
     * @return array
     */
    private function valuesAddon(): array
    {
        return [
            'M' => [
            /* I18N: Spelling based on a local Taishanese pronunciation anglicized by untrained workers */
            self::VALUE_HOISAN      => I18N::translate('MALE', 'Hoisan 台山话 name'),
            /* I18N: Spelling based on the Chinese dialect pronunciation anglicized by untrained workers */
            self::VALUE_PHONETIC    => I18N::translate('local phonetic name'),
            /* I18N: A name given to an individual which was purchased for entry into the United States */
            self::VALUE_PAPER       => I18N::translate('paper name'),
            /* I18N: The Chinese character set introduced by the Peoples Republic of China*/
            self::VALUE_SIMPLIFIED  => I18N::translate('simplified characters'),
            /* I18N: The Chinese character set commonly used before the Peoples Republic of China */
            self::VALUE_TRADITIONAL => I18N::translate('traditional characters'),
            /* I18N: One type of Cantonese romanization */
            self::VALUE_YALE        => I18N::translate('耶鲁/耶魯 yale romanization'),
            /* I18N: One type of Cantonese romanization */
            self::VALUE_JYUTPING    => I18N::translate('粤拼/粵拼 jyutping romanization'),
			/* I18N: The official romanization of the Peoples Republic of China */
            self::VALUE_PINYIN      => I18N::translate('拼音 pinyin name'),
			/* I18N: A name given to an individual during the Ancestral Village Coming of Age ceremony */
            self::VALUE_ZI          => I18N::translate('字 zi name'),
            /* I18N: A name chosen by or given to an individual, to replace their existing name */
            self::VALUE_HAO         => I18N::translate('號 hao name'),
            /* I18N: A name given to a male after their Style name, aka adult name */
            self::VALUE_HUI         => I18N::translate('號 hui name'),
            /* I18N: The baby name given to an individual and only used by the immediate family */
            self::VALUE_MILK        => I18N::translate('名 milk name'),
 			/* I18N: Baby name*/
            self::VALUE_BABY        => I18N::translate('MALE', '諱 shun or conceal baby name'),
            ],
            'F' => [
            /* I18N: Spelling based on a local Taishanese pronunciation anglicized by untrained workers */
            self::VALUE_HOISAN      => I18N::translate('FEMALE', 'Hoisan 台山话 name'),
            /* I18N: Spelling based on the Chinese dialect pronunciation anglicized by untrained workers */
            self::VALUE_PHONETIC    => I18N::translate('local phonetic name'),
            /* I18N: A name given to an individual which was purchased for entry into the United States */
            self::VALUE_PAPER       => I18N::translate('paper name'),
            /* I18N: The Chinese character set introduced by the Peoples Republic of China*/
            self::VALUE_SIMPLIFIED  => I18N::translate('simplified characters'),
            /* I18N: The Chinese character set commonly used before the Peoples Republic of China */
            self::VALUE_TRADITIONAL => I18N::translate('traditional characters'),
            /* I18N: One type of Cantonese romanization */
            self::VALUE_YALE        => I18N::translate('耶鲁/耶魯 yale romanization'),
            /* I18N: One type of Cantonese romanization */
            self::VALUE_JYUTPING    => I18N::translate('粤拼/粵拼 jyutping romanization'),
			/* I18N: The official romanization of the Peoples Republic of China */
            self::VALUE_PINYIN      => I18N::translate('拼音 pinyin name'),
			/* I18N: A name given to an individual during the Ancestral Village Coming of Age ceremony */
            self::VALUE_ZI          => I18N::translate('字 zi name'),
            /* I18N: A name chosen by or given to an individual, to replace their existing name */
            self::VALUE_HAO         => I18N::translate('號 hao name'),
            /* I18N: A name given to a male after their Style name, aka adult name */
            self::VALUE_HUI         => I18N::translate('號 hui name'),
            /* I18N: The baby name given to an individual and only used by the immediate family */
            self::VALUE_MILK        => I18N::translate('名 milk name'),
 			/* I18N: Baby name*/
            self::VALUE_BABY        => I18N::translate('FEMALE', '諱 shun or conceal baby name'),
            ],
            'U' => [
            /* I18N: Spelling based on a local Taishanese pronunciation anglicized by untrained workers */
            self::VALUE_HOISAN      => I18N::translate('Hoisan 台山话 name'),
            /* I18N: Spelling based on the Chinese dialect pronunciation anglicized by untrained workers */
            self::VALUE_PHONETIC    => I18N::translate('local phonetic name'),
            /* I18N: A name given to an individual which was purchased for entry into the United States */
            self::VALUE_PAPER       => I18N::translate('paper name'),
            /* I18N: The Chinese character set introduced by the Peoples Republic of China*/
            self::VALUE_SIMPLIFIED  => I18N::translate('simplified characters'),
            /* I18N: The Chinese character set commonly used before the Peoples Republic of China */
            self::VALUE_TRADITIONAL => I18N::translate('traditional characters'),
            /* I18N: One type of Cantonese romanization */
            self::VALUE_YALE        => I18N::translate('耶鲁/耶魯 yale romanization'),
            /* I18N: One type of Cantonese romanization */
            self::VALUE_JYUTPING    => I18N::translate('粤拼/粵拼 jyutping romanization'),
			/* I18N: The official romanization of the Peoples Republic of China */
            self::VALUE_PINYIN      => I18N::translate('拼音 pinyin name'),
			/* I18N: A name given to an individual during the Ancestral Village Coming of Age ceremony */
            self::VALUE_ZI          => I18N::translate('字 zi name'),
            /* I18N: A name chosen by or given to an individual, to replace their existing name */
            self::VALUE_HAO         => I18N::translate('號 hao name'),
            /* I18N: A name given to a male after their Style name, aka adult name */
            self::VALUE_HUI         => I18N::translate('號 hui name'),
            /* I18N: The baby name given to an individual and only used by the immediate family */
            self::VALUE_MILK        => I18N::translate('名 milk name'),
 			/* I18N: Baby name*/
            self::VALUE_BABY        => I18N::translate('諱 shun or conceal baby name'),
			],
        ];
    }

    /**
     * original value list as a copy from /app/Elements/NameType
     *
     * @return array
     */
    private function valuesOriginal(): array
    {
        foreach (self::SEX as $sexPart) {
            $values[$sexPart] = NameType::values($sexPart);
        }
        return $values;
    }

    /**
     * @param string $sex - the text depends on the sex of the *linked* individual
     * @return array
     */
    public function values(string $sex = 'U'): array
    {
        $values = [];
        $valuesOriginal = $this->valuesOriginal();
        $valuesAddon = $this->valuesAddon();
        foreach (self::SEX as $sexPart) {
            $values[$sexPart] = array_merge($valuesOriginal[$sexPart], $valuesAddon[$sexPart]);
        }

        $tmp = $values[$sex] ?? $values['U'];
        uasort($tmp, I18N::comparator());

        return $tmp;
    }
}
