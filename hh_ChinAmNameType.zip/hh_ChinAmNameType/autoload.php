<?php

namespace Hartenthaler\Webtrees\Module\ChinAmNameTypeAddon;

use Composer\Autoload\ClassLoader;

$loader = new ClassLoader();
$loader->addPsr4('Hartenthaler\\Webtrees\\Module\\ChinAmNameTypeAddon\\', __DIR__);
$loader->register();
